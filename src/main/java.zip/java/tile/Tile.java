package tile;

import java.awt.image.BufferedImage;

// This is a structure for a tile
public class Tile {
    public BufferedImage image;
    public boolean occupied = false;
}